package com.carscreen.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val obd by lazy {
        Obd(this,
            { json -> web.post { web.evaluateJavascript("onObd($json)", null) } },
            { st -> web.post { web.evaluateJavascript("onObdStatus(" + org.json.JSONObject.quote(st) + ")", null) } })
    }

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uris = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                1
            )
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                setGeolocationEnabled(true)
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                allowFileAccess = false
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val u = request.url
                    if (u.scheme == "tel") {
                        startActivity(Intent(Intent.ACTION_DIAL, u))
                        return true
                    }
                    return false
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String, callback: GeolocationPermissions.Callback
                ) {
                    callback.invoke(origin, true, false)
                }

                override fun onShowFileChooser(
                    w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = cb
                    return try {
                        chooser.launch(params.createIntent())
                        true
                    } catch (e: Exception) {
                        fileCallback = null
                        false
                    }
                }
            }
            addJavascriptInterface(object {
                @android.webkit.JavascriptInterface
                fun openUrl(url: String) {
                    try {
                        val u = Uri.parse(url)
                        val i = Intent(if (u.scheme == "tel") Intent.ACTION_DIAL else Intent.ACTION_VIEW, u)
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) { }
                }
                @android.webkit.JavascriptInterface
                fun launchApp(pkg: String, url: String) {
                    try {
                        val li = packageManager.getLaunchIntentForPackage(pkg)
                        if (li != null) {
                            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(li)
                            return
                        }
                    } catch (e: Exception) { }
                    if (url.isNotEmpty()) openUrl(url)
                }
                @android.webkit.JavascriptInterface
                fun listApps(): String {
                    val arr = org.json.JSONArray()
                    try {
                        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        for (r in packageManager.queryIntentActivities(q, 0)) {
                            if (r.activityInfo.packageName == packageName) continue
                            val o = org.json.JSONObject()
                            o.put("label", r.loadLabel(packageManager).toString())
                            o.put("pkg", r.activityInfo.packageName)
                            arr.put(o)
                        }
                    } catch (e: Exception) { }
                    return arr.toString()
                }
                @android.webkit.JavascriptInterface
                fun getVolume(): Int {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    return if (max > 0) am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max else 0
                }
                @android.webkit.JavascriptInterface
                fun setVolume(percent: Int) {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    val p = if (percent < 0) 0 else if (percent > 100) 100 else percent
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (p * max + 50) / 100, 0)
                }
                @android.webkit.JavascriptInterface
                fun obdConnect(host: String, port: Int) { obd.start(host, port) }
                @android.webkit.JavascriptInterface
                fun obdDisconnect() { obd.stop() }
            }, "Android")
            loadUrl("https://appassets.androidplatform.net/assets/index.html")
        }
        setContentView(web)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("setMode('home')", null)
            }
        })
    }

    // لما يضغط زر Home حق النظام والتطبيق شغال، نرجع للشاشة الرئيسية
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        web.post { web.evaluateJavascript("setMode('home')", null) }
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        super.onPause()
        // نخلي الموسيقى تكمل في الخلفية
    }

    override fun onDestroy() {
        obd.stop()
        web.destroy()
        super.onDestroy()
    }
}
