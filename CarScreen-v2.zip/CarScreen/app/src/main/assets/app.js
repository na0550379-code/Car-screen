const $=id=>document.getElementById(id);
const app=$('app'),main=$('main'),store=$('store');
const pad=n=>String(n).padStart(2,'0');

/* ================= أخطاء (تظهر على الشاشة بدل ما تخرب كل شي) ================= */
function reportErr(e){
  try{const el=$('err');el.textContent='⚠ '+(e&&e.message?e.message:e);el.style.display='block';clearTimeout(reportErr.t);reportErr.t=setTimeout(()=>el.style.display='none',9000)}catch(_){}
}
window.addEventListener('error',e=>reportErr(e.message+(e.lineno?' @'+e.lineno:'')));
window.addEventListener('unhandledrejection',e=>reportErr(e.reason));
const safe=fn=>{try{return fn()}catch(e){reportErr(e)}};
const NOOP=new Proxy(()=>{},{get:(t,p)=>p===Symbol.toPrimitive?()=>'':NOOP,apply:()=>NOOP});

/* ================= اللغة ================= */
const T={
 phone:['Phone','هاتف'],nav:['Navigation','الملاحة'],media:['Media','الوسائط'],veh:['Vehicle','السيارة'],
 noTrack:['Unknown Track','أغنية غير معروفة'],noArtist:['Unknown Artist','فنان غير معروف'],
 add:['Add music','إضافة موسيقى'],plist:['Playlist','قائمة الأغاني'],empty:['Playlist is empty','القائمة فاضية'],player:['Player','المشغّل'],
 carPick:['Change car image','تغيير صورة السيارة'],carReset:['Original car image','الصورة الأصلية'],
 photoPick:['Change photo widget image','تغيير صورة ويدجت الصورة'],custom:['Customize screen','تخصيص الشاشة'],
 fs:['Fullscreen','ملء الشاشة'],wake:['Keep screen on','إبقاء الشاشة شغالة'],
 done:['Done','تم'],tap:['Tap to change','اضغط للتغيير'],choose:['Choose a widget','اختر الويدجت'],
 search:['Search a place or address','ابحث عن مكان أو عنوان'],go:['Go','اذهب'],
 noRoute:['Choose a destination from Navigation','اختر وجهتك من «الملاحة»'],
 avg:['avg km/h','متوسط السرعة'],max:['max km/h','أعلى سرعة'],reset:['Reset trip','تصفير الرحلة'],
 pickPhoto:['Tap to choose a photo','اضغط لاختيار صورة'],
 km:['km','كم'],m:['m','م'],min:['min','د'],
 vdata:['Vehicle data','بيانات السيارة'],settings:['Settings','الإعدادات'],obdConn:['Connect OBD','اتصال OBD'],obdDisc:['Disconnect','قطع الاتصال'],
 demo:['Demo','تجريبي'],demoStop:['Stop demo','إيقاف التجريبي'],needApk:['OBD needs the Android app (APK)','الـ OBD يحتاج تطبيق الأندرويد (APK)'],
 iconSize:['Icon size','حجم الأيقونات'],screenSize:['Screen size','حجم الشاشة'],resetSize:['Reset sizes','إرجاع الأحجام'],
 stConnecting:['Connecting…','جاري الاتصال…'],stConnected:['Connected','متصل'],stClosed:['Not connected','غير متصل'],stError:['Error','خطأ'],
 vidPick:['Choose video','اختر فيديو'],vidHint:['Pick a video from the flash drive or storage','اختر فيديو من الفلاش أو الذاكرة'],
 vidErr:['Cannot play this video','ما قدرت أشغّل هذا الفيديو'],fit:['Fit','ملاءمة'],fill:['Fill','تعبئة'],
 nomap:['Map needs internet','الخريطة تحتاج إنترنت'],
 clockFmt:['Clock format','نظام الساعة'],h24:['24-hour','24 ساعة'],h12:['12-hour','12 ساعة'],
 topSpd:['Speed in top bar','السرعة في الشريط العلوي'],topClock:['Clock in top bar','الساعة في الشريط العلوي'],topTemp:['Temperature in top bar','الحرارة في الشريط العلوي'],
 on:['Shown','ظاهر'],off:['Hidden','مخفي'],
 limMode:['Speed limit','حد السرعة'],limAuto:['Auto (from map)','تلقائي من الخرائط'],limManual:['Manual','يدوي'],
 allApps:['All apps','كل التطبيقات'],appsOnly:['Available in the Android app only','متوفر في تطبيق الأندرويد فقط'],
 modeHome:['Home','الرئيسية'],modeVideo:['Video','الفيديو'],modeMusic:['Music','الأغاني'],
 gpsOff:['Turn on location (GPS)','فعّل الموقع (GPS)'],noGpsFix:['Waiting for GPS fix','انتظر تحديد موقعك (GPS)'],
 noRouteFound:['No route found','ما لقيت طريق'],checkNet:['Check your internet connection','تحقق من الإنترنت'],
 rerouting:['Rerouting...','إعادة حساب المسار...'],arrived:['You have arrived','وصلت إلى وجهتك'],searching:['Searching...','جاري البحث...'],
 notFound:['Place not found','ما لقيت المكان'],imgOk:['Image updated','تم تغيير الصورة'],imgReset:['Original image restored','رجعت الصورة الأصلية'],
 wakeOk:['Screen will stay on','الشاشة بتبقى شغالة'],notSup:['Not supported','غير مدعوم']
};
let LANG=1;
function t(k){return T[k]?T[k][LANG]:k}

/* ================= الويدجتات والتقسيمات ================= */
const WN={
 map:['Map','الخريطة','🗺️'],music:['Music','الموسيقى','🎵'],speed:['Speed','السرعة','🚗'],car:['Car image','صورة السيارة','🚘'],
 clock:['Clock','الساعة','🕒'],weather:['Weather','الطقس','⛅'],compass:['Compass','البوصلة','🧭'],turn:['Next turn','التوجيه','↱'],
 trip:['Trip','الرحلة','📊'],photo:['Photo','صورة','🖼️'],apps:['Shortcuts','اختصارات','🚀'],logo:['Logo','الشعار','✦'],gauges:['Gauges','المؤشرات','⛽'],blank:['Empty','فارغ','⬛']
};
const W={map:$('w-map'),music:$('w-music'),speed:$('w-speed'),car:$('w-car'),clock:$('w-clock'),weather:$('w-weather'),compass:$('w-compass'),turn:$('w-turn'),trip:$('w-trip'),photo:$('w-photo'),apps:$('w-apps'),gauges:$('w-gauges'),logo:$('w-logo')};
const LAYOUTS={
 classic:{areas:'"a b c" "a b d"',cols:'27.5% 1fr 27.5%',rows:'1fr 1fr',slots:['a','b','c','d']},
 bigmap:{areas:'"a b" "c b"',cols:'32% 1fr',rows:'1fr 1fr',slots:['a','b','c']},
 trio:{areas:'"a b c"',cols:'1fr 1fr 1fr',rows:'1fr',slots:['a','b','c']},
 quad:{areas:'"a b" "c d"',cols:'1fr 1fr',rows:'1fr 1fr',slots:['a','b','c','d']},
 two:{areas:'"a b"',cols:'1fr 1fr',rows:'1fr',slots:['a','b']},
 single:{areas:'"a"',cols:'1fr',rows:'1fr',slots:['a']}
};
const DEF={layout:'classic',slots:{a:'music',b:'map',c:'turn',d:'speed'},lang:1,is:1,ss:1,h24:true,topSpd:true,topClock:true,topTemp:true,autoLimit:true};
let cfg=JSON.parse(JSON.stringify(DEF));
try{
  const s=JSON.parse(localStorage.getItem('cfg2')||'null');
  if(s&&LAYOUTS[s.layout]){cfg=Object.assign(cfg,s);cfg.slots=Object.assign({},DEF.slots,s.slots)}
}catch(e){}
LANG=cfg.lang==null?1:cfg.lang;
const save=()=>{cfg.lang=LANG;try{localStorage.setItem('cfg2',JSON.stringify(cfg))}catch(e){}};

function place(){
  const L=LAYOUTS[cfg.layout];
  main.style.gridTemplateAreas=L.areas;main.style.gridTemplateColumns=L.cols;main.style.gridTemplateRows=L.rows;
  Object.values(W).forEach(el=>store.appendChild(el));
  ['a','b','c','d'].forEach(s=>{
    const slot=document.querySelector(`.slot[data-slot=${s}]`);
    const on=L.slots.includes(s);slot.style.display=on?'':'none';
    const wid=cfg.slots[s];
    if(on&&W[wid])slot.insertBefore(W[wid],slot.firstChild);
  });
  if(app.dataset.mode==='nav')$('navFull').appendChild(W.map);
  refreshCovers();
  setTimeout(()=>{try{map.invalidateSize({pan:false})}catch(e){}},80);
}
function refreshCovers(){
  document.querySelectorAll('.cover').forEach(c=>{
    const wid=cfg.slots[c.dataset.for];
    c.innerHTML=`<div>${WN[wid][2]} ${WN[wid][LANG]}</div><small>${t('tap')}</small>`;
  });
}
function assign(slot,wid){
  if(wid!=='blank'){
    for(const s of ['a','b','c','d']){ if(s!==slot&&cfg.slots[s]===wid){cfg.slots[s]=cfg.slots[slot]} }
  }
  cfg.slots[slot]=wid;save();place();
}
let pickSlot=null;
function buildPicker(){
  const g=$('pgrid');g.innerHTML='';
  Object.keys(WN).forEach(id=>{
    const b=document.createElement('button');
    b.innerHTML=`<span>${WN[id][2]}</span>${WN[id][LANG]}`;
    if(pickSlot&&cfg.slots[pickSlot]===id)b.className='on';
    b.onclick=()=>{assign(pickSlot,id);closePicker()};
    g.appendChild(b);
  });
}
function openPicker(slot){pickSlot=slot;$('pbox-h').textContent=t('choose');buildPicker();$('picker').classList.add('on')}
function closePicker(){$('picker').classList.remove('on');pickSlot=null}
$('picker').onclick=e=>{if(e.target===$('picker'))closePicker()};
document.querySelectorAll('.cover').forEach(c=>c.onclick=()=>openPicker(c.dataset.for));

function buildEditBar(){
  const bar=$('editBar');bar.innerHTML='';
  Object.entries(LAYOUTS).forEach(([k,L])=>{
    const b=document.createElement('button');b.className='lay'+(k===cfg.layout?' on':'');
    const m=document.createElement('div');m.className='mini';
    m.style.gridTemplateAreas=L.areas;m.style.gridTemplateColumns=L.cols.includes('%')?'27% 1fr 27%':L.cols;m.style.gridTemplateRows=L.rows;
    L.slots.forEach(s=>{const i=document.createElement('i');i.style.gridArea=s;m.appendChild(i)});
    b.appendChild(m);b.onclick=()=>{cfg.layout=k;save();place();buildEditBar()};bar.appendChild(b);
  });
  const lg=document.createElement('button');lg.className='lang';lg.textContent=LANG?'EN':'عربي';
  lg.onclick=()=>{LANG=LANG?0:1;save();applyLang()};bar.appendChild(lg);
  const d=document.createElement('button');d.className='go';d.textContent=t('done');d.onclick=()=>setMode('home');bar.appendChild(d);
}
// ضغطة مطولة على أي كرت تفتح التخصيص
document.querySelectorAll('.slot').forEach(sl=>{
  let tm=null,x0=0,y0=0;
  sl.addEventListener('pointerdown',e=>{
    if(app.dataset.mode!=='home')return;
    x0=e.clientX;y0=e.clientY;
    tm=setTimeout(()=>{setMode('edit');openPicker(sl.dataset.slot)},800);
  });
  const stop=()=>{clearTimeout(tm)};
  sl.addEventListener('pointerup',stop);sl.addEventListener('pointercancel',stop);
  sl.addEventListener('pointermove',e=>{if(Math.hypot(e.clientX-x0,e.clientY-y0)>12)stop()});
});

/* ================= رسائل سريعة ================= */
function say(m,ms=3200){const e=$('toast');e.textContent=m;e.style.display='block';clearTimeout(say.t);say.t=setTimeout(()=>e.style.display='none',ms)}

/* ================= الأوضاع ================= */
const GLOW={nav:'b-nav',media:'b-media',music:'b-media',veh:'b-veh',vset:'b-veh',home:'b-nav',edit:'b-nav'};
function setMode(m){
  const prev=app.dataset.mode;
  if(m!=='edit')closePicker();
  if(prev==='video'&&m!=='video'){try{vid.pause()}catch(e){}setImmersive(false)}
  app.dataset.mode=m;
  place();
  setTilt(tiltWanted);
  $('glow').className='glow '+(GLOW[m]||'b-home');
  if(m==='video'){try{audio.pause()}catch(e){}showVCtl()}
  if(m==='nav')setTimeout(()=>$('q').focus(),200);
}
// زر المرسيدس: رئيسية ← فيديو ← أغاني ← رئيسية
const CYCLE=['home','video','music'];
$('bHome2').onclick=()=>{
  const i=CYCLE.indexOf(app.dataset.mode);
  const nx=i<0?'home':CYCLE[(i+1)%CYCLE.length];
  setMode(nx);
  say({home:t('modeHome'),video:t('modeVideo'),music:t('modeMusic')}[nx],1600);
};
$('bHome').onclick=()=>setMode('home');
$('bBack').onclick=()=>{
  if($('picker').classList.contains('on'))closePicker();
  else if(app.classList.contains('immersive'))setImmersive(false);
  else setMode('home');
};
$('bNav').onclick=()=>setMode(app.dataset.mode==='nav'?'home':'nav');
$('bMedia').onclick=()=>setMode(app.dataset.mode==='music'?'home':'music');
$('bVeh').onclick=()=>setMode(app.dataset.mode==='veh'?'home':'veh');
$('customBtn').onclick=()=>setMode('edit');
$('toSet').onclick=()=>setMode('vset');$('toData').onclick=()=>setMode('veh');
function openExt(u){try{if(window.Android&&Android.openUrl){Android.openUrl(u);return}}catch(e){}window.open(u,'_blank')}
function openApp(pkg,url){try{if(window.Android&&Android.launchApp){Android.launchApp(pkg,url);return}}catch(e){}openExt(url)}
$('bPhone').onclick=()=>openExt('tel:');

/* ================= كل التطبيقات (لأن البرنامج هو الشاشة الرئيسية) ================= */
function openAllApps(){
  let list=[];
  try{if(window.Android&&Android.listApps)list=JSON.parse(Android.listApps())}catch(e){}
  if(!list.length){say(t('appsOnly'));return}
  list.sort((a,b)=>a.label.localeCompare(b.label));
  pickSlot=null;$('pbox-h').textContent=t('allApps');
  const g=$('pgrid');g.innerHTML='';
  list.forEach(a=>{
    const b=document.createElement('button');
    b.innerHTML=`<span>${(a.label||'?').trim().charAt(0).toUpperCase()}</span>${a.label}`;
    b.onclick=()=>{closePicker();openApp(a.pkg,'')};
    g.appendChild(b);
  });
  $('picker').classList.add('on');
}
$('allApps').onclick=openAllApps;

/* ================= الشريط العلوي والساعة ================= */
function fmtClock(d){
  let h=d.getHours(),suf='';
  if(cfg.h24)h=pad(h);else{suf=' '+(h<12?(LANG?'ص':'AM'):(LANG?'م':'PM'));h=h%12||12}
  return h+':'+pad(d.getMinutes())+suf;
}
function paintTop(){
  $('iSpd').style.display=cfg.topSpd?'':'none';
  $('iClock').style.display=cfg.topClock?'':'none';
  $('iTemp').style.display=cfg.topTemp?'':'none';
}
function tick(){
  const d=new Date();const tm=fmtClock(d);
  $('time').textContent=tm;$('ck-time').textContent=tm;
  $('ck-date').textContent=d.toLocaleDateString(LANG?'ar-SA':'en-GB',{weekday:'long',day:'numeric',month:'long'});
  $('top').classList.toggle('off',!navigator.onLine);
  trip.tick();
}

/* ================= الطقس والحرارة ================= */
const WX={0:['Clear','صافي','☀️'],1:['Mostly clear','صافي غالباً','🌤️'],2:['Partly cloudy','غائم جزئياً','⛅'],3:['Cloudy','غائم','☁️'],45:['Fog','ضباب','🌫️'],48:['Fog','ضباب','🌫️'],51:['Drizzle','رذاذ','🌦️'],53:['Drizzle','رذاذ','🌦️'],55:['Drizzle','رذاذ','🌦️'],61:['Rain','مطر','🌧️'],63:['Rain','مطر','🌧️'],65:['Heavy rain','مطر غزير','🌧️'],71:['Snow','ثلج','❄️'],73:['Snow','ثلج','❄️'],75:['Snow','ثلج','❄️'],80:['Showers','زخات','🌦️'],81:['Showers','زخات','🌦️'],82:['Showers','زخات','🌦️'],95:['Thunderstorm','عاصفة رعدية','⛈️'],96:['Thunderstorm','عاصفة رعدية','⛈️'],99:['Thunderstorm','عاصفة رعدية','⛈️']};
let lastWx=0,tempWx=null,tempObd=null,tempObdAt=0;
function paintTemp(){
  const v=(tempObd!=null&&Date.now()-tempObdAt<30000)?tempObd:tempWx;
  $('temp').textContent=v==null?'--°C':v.toFixed(1)+'°C';
  $('wx-t').textContent=v==null?'--°':Math.round(v)+'°';
}
async function weather(ll){
  if(Date.now()-lastWx<600000)return;lastWx=Date.now();
  try{
    const j=await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${ll[0]}&longitude=${ll[1]}&current=temperature_2m,weather_code,wind_speed_10m`)).json();
    const c=j.current,w=WX[c.weather_code]||WX[2];
    tempWx=c.temperature_2m;paintTemp();
    $('wx-em').textContent=w[2];$('wx-d').textContent=w[LANG];
    $('wx-w').textContent=Math.round(c.wind_speed_10m)+' km/h';
  }catch(e){lastWx=Date.now()-540000}
}

/* ================= الخريطة (Leaflet يتحمّل بالخلفية ولا يوقف التطبيق) ================= */
let map=NOOP,mapReady=false;
const carSvg='<svg viewBox="0 0 76 60"><ellipse cx="38" cy="30" rx="35" ry="26" fill="#0a2a52" stroke="#d9dee4" stroke-width="3.500"/><path d="M38 10 54 42 38 34 22 42z" fill="#e8edf2"/></svg>';
let meMarker=null,follow=true,lastLL=null,heading=0,gotFirst=false,tiltWanted=true,tilt=false;
const LSRC=[
 ['https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js','https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css'],
 ['https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js','https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css'],
 ['https://unpkg.com/leaflet@1.9.4/dist/leaflet.js','https://unpkg.com/leaflet@1.9.4/dist/leaflet.css']
];
function loadLeaflet(i){
  if(mapReady)return;
  if(i>=LSRC.length){setTimeout(()=>loadLeaflet(0),30000);return}
  const l=document.createElement('link');l.rel='stylesheet';l.href=LSRC[i][1];document.head.appendChild(l);
  const s=document.createElement('script');s.src=LSRC[i][0];
  s.onload=()=>{if(window.L&&L.map)safe(initMap);else loadLeaflet(i+1)};
  s.onerror=()=>loadLeaflet(i+1);
  document.head.appendChild(s);
}
function initMap(){
  if(mapReady)return;
  map=L.map('map',{zoomControl:false,attributionControl:true}).setView(lastLL||[24.7136,46.6753],lastLL?16:13);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
  mapReady=true;$('nomap').style.display='none';
  map.on('dragstart',()=>follow=false);
  if(lastLL)makeMarker(lastLL);
  drawRoute();
  setTilt(tiltWanted);
}
function makeMarker(ll){
  if(!mapReady)return;
  if(!meMarker){
    meMarker=L.marker(ll,{icon:L.divIcon({className:'me',html:carSvg,iconSize:[60,48],iconAnchor:[30,24]}),zIndexOffset:1000}).addTo(map);
    if(tilt&&meMarker.getElement())meMarker.getElement().style.display='none';
  }else meMarker.setLatLng(ll);
}
function setTilt(want){
  tiltWanted=want;
  const eff=want&&app.dataset.mode!=='nav';
  tilt=eff;
  W.map.classList.toggle('tilt',eff);
  if(eff){map.dragging.disable();map.touchZoom.disable();map.doubleClickZoom.disable();map.boxZoom.disable()}
  else{map.dragging.enable();map.touchZoom.enable();map.doubleClickZoom.enable();$('map').style.transform=''}
  if(meMarker&&meMarker.getElement())meMarker.getElement().style.display=eff?'none':'';
  setTimeout(()=>{try{map.invalidateSize({pan:false});if(eff&&lastLL){follow=true;map.setView(lastLL,17,{animate:false})}}catch(e){}applyTilt()},90);
}
function applyTilt(){if(tilt)$('map').style.transform=`perspective(900px) rotateX(36deg) rotateZ(${-heading}deg)`}
let curSpeed=0;
function setSpeed(k){curSpeed=k;$('spd').textContent=k;$('topSpd').textContent=k;paintOver()}
function onPos(p){
  const c=p.coords,ll=[c.latitude,c.longitude];
  const kmh=c.speed!=null&&c.speed>0.5?Math.round(c.speed*3.6):0;
  if(Date.now()-obdSpeedAt>3000)setSpeed(kmh);
  if(c.heading!=null&&!isNaN(c.heading)&&kmh>3)heading=c.heading;
  $('rose').style.transform=`rotate(${-heading}deg)`;
  const dirs=LANG?['ش','ش.ق','ق','ج.ق','ج','ج.غ','غ','ش.غ']:['N','NE','E','SE','S','SW','W','NW'];
  $('cmp-t').textContent=Math.round(heading)+'° '+dirs[Math.round(heading/45)%8];
  trip.add(ll,kmh,c.accuracy);
  lastLL=ll;
  makeMarker(ll);
  if(!gotFirst){gotFirst=true;try{map.setView(ll,tilt?17:16,{animate:false})}catch(e){}}
  else if(follow){try{map.panTo(ll,{animate:true,duration:.6,easeLinearity:1})}catch(e){}}
  applyTilt();weather(ll);fetchLimit(ll,kmh);updateRoute(ll);
}
function startGPS(){
  if(!navigator.geolocation){say('GPS not supported');return}
  navigator.geolocation.watchPosition(p=>safe(()=>onPos(p)),()=>say(t('gpsOff')),{enableHighAccuracy:true,maximumAge:1000});
}
$('loc').onclick=()=>{follow=true;if(app.dataset.mode!=='nav')setTilt(true);if(lastLL){try{map.setView(lastLL,tilt?17:16)}catch(e){}}else startGPS()};
$('map').addEventListener('pointerdown',()=>{if(tilt&&app.dataset.mode==='home'){follow=false;setTilt(false)}});

/* ================= المسار والتوجيه (ويدجت منفصل بأسهم) ================= */
let routeLine=null,routeGlow=null,steps=[],stepIdx=0,dest=null,coordsArr=[],lastReroute=0;
const R=6371000,rad=x=>x*Math.PI/180;
function hav(a,b){const dl=rad(b[0]-a[0]),dn=rad(b[1]-a[1]);const h=Math.sin(dl/2)**2+Math.cos(rad(a[0]))*Math.cos(rad(b[0]))*Math.sin(dn/2)**2;return 2*R*Math.asin(Math.sqrt(h))}
function fmtDist(m){return m<1000?(Math.round(m/10)*10)+' '+t('m'):(m/1000).toFixed(1)+' '+t('km')}
const ARW={
 straight:'<path d="M50 90V20M28 42 50 18 72 42"/>',
 left:'<path d="M62 92V58Q62 38 42 38H16M32 22 14 38 32 54"/>',
 right:'<path d="M38 92V58Q38 38 58 38H84M68 22 86 38 68 54"/>',
 slightleft:'<g transform="rotate(-38 50 55)"><path d="M50 90V20M28 42 50 18 72 42"/></g>',
 slightright:'<g transform="rotate(38 50 55)"><path d="M50 90V20M28 42 50 18 72 42"/></g>',
 sharpleft:'<g transform="rotate(-125 50 55)"><path d="M50 90V20M28 42 50 18 72 42"/></g>',
 sharpright:'<g transform="rotate(125 50 55)"><path d="M50 90V20M28 42 50 18 72 42"/></g>',
 uturn:'<path d="M30 92V42Q30 16 52 16Q74 16 74 42V62M58 48 74 64 90 48"/>',
 roundabout:'<circle cx="50" cy="50" r="22"/><path d="M50 92V72M72 50H90M78 38 90 50 78 62"/>',
 arrive:'<path d="M30 92V12M30 16H78L63 34 78 52H30"/>'
};
function arrowHtml(k){return `<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="9" stroke-linecap="round" stroke-linejoin="round">${ARW[k]||ARW.straight}</svg>`}
function setTurn(key,d,i,eta){
  document.querySelectorAll('.t-arr').forEach(e=>e.innerHTML=arrowHtml(key));
  document.querySelectorAll('.t-dist').forEach(e=>e.textContent=d);
  document.querySelectorAll('.t-ins').forEach(e=>e.textContent=i);
  document.querySelectorAll('.t-eta').forEach(e=>e.textContent=eta||'');
  document.querySelectorAll('.w-turn').forEach(e=>e.classList.toggle('idle',!steps.length));
}
const INS={
 arrive:['You have arrived','وصلت إلى وجهتك'],depart:['Start driving','ابدأ بالتحرك'],roundabout:['Enter the roundabout','ادخل الدوار'],
 left:['Turn left','انعطف يسار'],right:['Turn right','انعطف يمين'],
 slightleft:['Bear left','انعطف قليلاً يسار'],slightright:['Bear right','انعطف قليلاً يمين'],
 sharpleft:['Sharp left','انعطف حاداً يسار'],sharpright:['Sharp right','انعطف حاداً يمين'],
 uturn:['Make a U-turn','استدر للخلف'],straight:['Continue straight','استمر مباشرة'],
 forkl:['Keep left','خذ المسار الأيسر'],forkr:['Keep right','خذ المسار الأيمن'],
 exitl:['Take the left exit','اخرج من المخرج الأيسر'],exitr:['Take the right exit','اخرج من المخرج الأيمن'],
 merge:['Merge','ادمج مع الطريق'],cont:['Continue','استمر في الطريق']
};
function instr(mv){
  const ty=mv.type,m=mv.modifier||'';
  if(ty==='arrive')return['arrive',INS.arrive[LANG]];
  if(ty==='depart')return['straight',INS.depart[LANG]];
  if(ty==='roundabout'||ty==='rotary'||ty==='roundabout turn')return['roundabout',INS.roundabout[LANG]];
  if(ty==='fork')return m.includes('left')?['slightleft',INS.forkl[LANG]]:['slightright',INS.forkr[LANG]];
  if(ty==='off ramp')return m.includes('left')?['slightleft',INS.exitl[LANG]]:['slightright',INS.exitr[LANG]];
  if(ty==='merge')return['straight',INS.merge[LANG]];
  const mp={'left':'left','right':'right','slight left':'slightleft','slight right':'slightright','sharp left':'sharpleft','sharp right':'sharpright','uturn':'uturn','straight':'straight'};
  const k=mp[m];
  return k?[k,INS[k][LANG]]:['straight',INS.cont[LANG]];
}
function drawRoute(){
  if(routeLine){routeLine.remove();routeGlow.remove();routeLine=null;routeGlow=null}
  if(!mapReady||!coordsArr.length)return;
  routeGlow=L.polyline(coordsArr,{color:'#1e8cff',weight:22,opacity:.25,lineJoin:'round'}).addTo(map);
  routeLine=L.polyline(coordsArr,{color:'#2a97ff',weight:10,opacity:1,lineJoin:'round'}).addTo(map);
}
async function routeTo(to,name){
  if(!lastLL){say(t('noGpsFix'));return}
  dest={ll:to,name};
  try{
    const u=`https://router.project-osrm.org/route/v1/driving/${lastLL[1]},${lastLL[0]};${to[1]},${to[0]}?overview=full&geometries=geojson&steps=true`;
    const j=await (await fetch(u)).json();
    if(!j.routes||!j.routes.length){say(t('noRouteFound'));return}
    const r=j.routes[0];
    coordsArr=r.geometry.coordinates.map(c=>[c[1],c[0]]);
    steps=r.legs[0].steps;stepIdx=0;
    drawRoute();
    app.classList.add('routing');follow=true;
    return r;
  }catch(e){say(t('checkNet'))}
}
function updateRoute(ll){
  if(!steps.length)return;
  while(stepIdx<steps.length-1&&hav(ll,[steps[stepIdx+1].maneuver.location[1],steps[stepIdx+1].maneuver.location[0]])<30)stepIdx++;
  const nxt=Math.min(stepIdx+1,steps.length-1);
  const mv=steps[nxt].maneuver;
  const target=[mv.location[1],mv.location[0]];
  const [a,ins]=instr(mv);const d=hav(ll,target);
  let remD=d,remT=0;
  for(let i=nxt;i<steps.length;i++){remD+=steps[i].distance;remT+=steps[i].duration}
  const cs=steps[stepIdx];if(cs&&cs.distance>0)remT+=cs.duration*Math.min(1,d/cs.distance);
  setTurn(a,fmtDist(d),ins,fmtDist(remD)+' • '+Math.max(1,Math.round(remT/60))+' '+t('min'));
  if(mv.type==='arrive'&&d<40){stopNav();say(t('arrived'));return}
  let min=1e9;for(let i=0;i<coordsArr.length;i+=3){const x=hav(ll,coordsArr[i]);if(x<min)min=x}
  if(min>180&&Date.now()-lastReroute>15000&&dest){lastReroute=Date.now();say(t('rerouting'));routeTo(dest.ll,dest.name)}
}
function stopNav(){
  steps=[];dest=null;coordsArr=[];drawRoute();
  app.classList.remove('routing');setTurn('straight','--',t('noRoute'));
}
$('stop').onclick=stopNav;$('stop2').onclick=stopNav;
async function search(){
  const q=$('q').value.trim();if(!q)return;
  say(t('searching'));
  try{
    const c=lastLL?`&viewbox=${lastLL[1]-1},${lastLL[0]+1},${lastLL[1]+1},${lastLL[0]-1}`:'';
    const j=await (await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=ar&q='+encodeURIComponent(q)+c)).json();
    if(!j.length){say(t('notFound'));return}
    const r=await routeTo([+j[0].lat,+j[0].lon],j[0].display_name);
    if(r){
      setMode('home');
      say(`${fmtDist(r.distance)} • ${Math.max(1,Math.round(r.duration/60))} ${t('min')}`,5000);
      if(lastLL){follow=true;setTilt(true)}
      updateRoute(lastLL);
    }
  }catch(e){say(t('checkNet'))}
}
$('goBtn').onclick=search;
$('q').addEventListener('keydown',e=>{if(e.key==='Enter')search()});

/* ================= السرعة وحد السرعة التلقائي من الخرائط (OpenStreetMap) ================= */
const LIMITS=[30,40,50,60,80,100,120,140];
let manualLimit=100;try{manualLimit=+localStorage.getItem('limit')||100}catch(e){}
let autoLim=0,autoEst=false;
const curLimit=()=>cfg.autoLimit?autoLim:manualLimit;
function paintOver(){const l=curLimit();W.speed.classList.toggle('over',!!l&&curSpeed>l)}
function paintLimit(){
  const l=curLimit(),est=cfg.autoLimit&&autoEst&&!!l;
  $('limit').textContent=l?(est?'~':'')+l:'--';
  $('limit').classList.toggle('est',est);
  paintOver();
}
// تعديل يدوي: ضغطة على علامة الحد تحوّل لوضع يدوي وتغيّر الرقم
$('limit').onclick=()=>{
  const base=curLimit()||manualLimit;
  manualLimit=LIMITS.find(x=>x>base)||LIMITS[0];
  cfg.autoLimit=false;save();
  try{localStorage.setItem('limit',manualLimit)}catch(e){}
  paintLimit();paintSettings();
};
const OVP=['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter'];
const HW_SKIP=new Set(['footway','path','cycleway','steps','pedestrian','bridleway','corridor','track','proposed','construction','raceway','elevator']);
const HW_EST={motorway:120,motorway_link:80,trunk:100,trunk_link:70,primary:80,primary_link:60,secondary:60,secondary_link:50,tertiary:50,tertiary_link:40,unclassified:50,residential:40,living_street:20,service:20};
function parseMax(v){
  if(!v)return 0;
  const m=/^\s*(\d{2,3})\s*(mph|km\/h|kmh)?\s*$/i.exec(String(v));
  if(!m)return 0;
  let n=+m[1];if(m[2]&&m[2].toLowerCase()==='mph')n=Math.round(n*1.609/5)*5;
  return n;
}
function distSeg(p,a,b){
  const k=Math.cos(rad(p[0])),X=q=>[(q.lon-p[1])*111320*k,(q.lat-p[0])*110540];
  const A=X(a),B=X(b),dx=B[0]-A[0],dy=B[1]-A[1],L2=dx*dx+dy*dy;
  const u=L2?Math.max(0,Math.min(1,-(A[0]*dx+A[1]*dy)/L2)):0;
  return Math.hypot(A[0]+u*dx,A[1]+u*dy);
}
let limPos=null,limT=0,limBusy=false;
async function fetchLimit(ll,kmh){
  if(!cfg.autoLimit||limBusy)return;
  const now=Date.now();
  if(limPos&&hav(limPos,ll)<120&&now-limT<45000)return;
  if(now-limT<8000)return;
  limBusy=true;limT=now;limPos=ll;
  try{
    const q=`[out:json][timeout:8];way(around:30,${ll[0].toFixed(6)},${ll[1].toFixed(6)})[highway];out tags geom 12;`;
    let j=null;
    for(const h of OVP){try{const r=await fetch(h+'?data='+encodeURIComponent(q));if(r.ok){j=await r.json();break}}catch(e){}}
    if(j){
      let best=null,bd=1e9;
      for(const w of j.elements||[]){
        const tg=w.tags||{};if(HW_SKIP.has(tg.highway)||!w.geometry||w.geometry.length<2)continue;
        let d=1e9;for(let i=0;i<w.geometry.length-1;i++)d=Math.min(d,distSeg(ll,w.geometry[i],w.geometry[i+1]));
        if(d<bd){bd=d;best=tg}
      }
      if(best){
        const mx=parseMax(best.maxspeed);
        if(mx){autoLim=mx;autoEst=false}
        else if(HW_EST[best.highway]){autoLim=HW_EST[best.highway];autoEst=true}
        paintLimit();
      }
    }
  }catch(e){}
  limBusy=false;
}

/* ================= الرحلة ================= */
const trip={d:0,max:0,t0:Date.now(),last:null,
 add(ll,kmh,acc){if(this.last&&acc<50){const m=hav(this.last,ll);if(m>6&&m<500)this.d+=m}if(!this.last||acc<50)this.last=ll;if(kmh>this.max)this.max=kmh},
 tick(){const s=(Date.now()-this.t0)/1000,h=s/3600;
  $('tr-d').textContent=(this.d/1000).toFixed(1);
  $('tr-t').textContent=Math.floor(s/3600)+':'+pad(Math.floor(s%3600/60));
  $('tr-a').textContent=h>0.003?Math.round(this.d/1000/h):0;$('tr-m').textContent=this.max},
 reset(){this.d=0;this.max=0;this.t0=Date.now();this.tick()}};
$('tr-r').onclick=()=>trip.reset();

/* ================= الصوت (أيقونة السماعة) ================= */
const IC={
 up:'M3 9v6h4l5 5V4L7 9H3zm13.500 3c0-1.770-1.020-3.290-2.500-4.030v8.050c1.480-.73 2.500-2.250 2.500-4.020zM14 3.230v2.060c2.890.86 5 3.540 5 6.710s-2.110 5.850-5 6.710v2.060c4.010-.91 7-4.490 7-8.770s-2.990-7.860-7-8.770z',
 dn:'M18.500 12c0-1.770-1.020-3.290-2.500-4.030v8.050c1.480-.73 2.500-2.250 2.500-4.020zM5 9v6h4l5 5V4L9 9H5z',
 off:'M16.500 12c0-1.770-1.020-3.290-2.500-4.030v2.210l2.450 2.450c.03-.2.050-.41.050-.63zm2.500 0c0 .94-.2 1.820-.54 2.640l1.510 1.510A8.800 8.800 0 0 0 21 12c0-4.280-2.990-7.860-7-8.770v2.060c2.890.86 5 3.540 5 6.710zM4.270 3 3 4.270 7.730 9H3v6h4l5 5v-6.730l4.250 4.250c-.67.52-1.420.93-2.250 1.180v2.060a8.990 8.990 0 0 0 3.690-1.810L19.730 21 21 19.730l-9-9L4.270 3zM12 4 9.910 6.090 12 8.180V4z',
 fs:'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z',
 fsx:'M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z'
};
const PLAY='<path d="M8 5v14l11-7z"/>',PAUSE='<path d="M6 5h4v14H6zm8 0h4v14h-4z"/>';
const hasA=()=>!!(window.Android&&Android.getVolume);
let vol=70,preMute=60,volT=null;
function readVol(){try{if(hasA()){const v=Android.getVolume();if(v>=0)return v}}catch(e){}return Math.round((audio.volume||0)*100)}
function paintVol(){
  const d=vol===0?IC.off:vol<40?IC.dn:IC.up;
  $('volIcon').setAttribute('d',d);$('volIcon2').setAttribute('d',d);
  $('volR').value=vol;$('volV').textContent=vol;
}
function applyVol(p){
  vol=Math.max(0,Math.min(100,Math.round(p)));
  try{if(hasA())Android.setVolume(vol);else{audio.volume=vol/100;vid.volume=vol/100}}catch(e){}
  paintVol();bumpVol();
}
function bumpVol(){clearTimeout(volT);volT=setTimeout(closeVol,5000)}
function openVol(){vol=readVol();paintVol();$('volPop').classList.add('on');$('volBack').classList.add('on');bumpVol()}
function closeVol(){clearTimeout(volT);$('volPop').classList.remove('on');$('volBack').classList.remove('on')}
$('bVol').onclick=()=>$('volPop').classList.contains('on')?closeVol():openVol();
$('volBack').onclick=closeVol;
$('volR').oninput=e=>applyVol(+e.target.value);
$('volDn').onclick=()=>applyVol(vol-5);
$('volUp').onclick=()=>applyVol(vol+5);
$('volMute').onclick=()=>{if(vol>0){preMute=vol;applyVol(0)}else applyVol(preMute||50)};

/* ================= الموسيقى ================= */
const audio=new Audio();let tracks=[],idx=-1;
function fmtT(s){
  if(!isFinite(s)||s<0)return '0:00';
  s=Math.floor(s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60);
  return h?h+':'+pad(m)+':'+pad(s%60):m+':'+pad(s%60);
}
function paintPlayer(){
  const tr=tracks[idx];
  document.querySelectorAll('.mTitle').forEach(e=>e.textContent=tr?tr.title:t('noTrack'));
  document.querySelectorAll('.mArtist').forEach(e=>e.textContent=tr?tr.artist:t('noArtist'));
  document.querySelectorAll('.mPi').forEach(e=>e.innerHTML=audio.paused?PLAY:PAUSE);
  const p=audio.duration?audio.currentTime/audio.duration*100:0;
  document.querySelectorAll('.mPb').forEach(e=>e.style.width=p+'%');
  document.querySelectorAll('.mCur').forEach(e=>e.textContent=fmtT(audio.currentTime));
  document.querySelectorAll('.mDur').forEach(e=>e.textContent=fmtT(audio.duration));
}
$('pick').onclick=$('mAdd').onclick=()=>$('file').click();
$('file').onchange=e=>{
  const first=tracks.length;
  for(const f of e.target.files){
    const n=f.name.replace(/\.[^.]+$/,''),p=n.split(' - ');
    tracks.push({title:p.length>1?p.slice(1).join(' - '):n,artist:p.length>1?p[0]:t('noArtist'),url:URL.createObjectURL(f)});
  }
  renderList();
  if(tracks.length>first){load(first,true);if(app.dataset.mode==='media')setMode('music')}
  e.target.value='';
};
function renderList(){
  const l=$('list');l.innerHTML='';
  if(!tracks.length){l.innerHTML=`<div class="empty">${t('empty')}</div>`;return}
  tracks.forEach((k,i)=>{const d=document.createElement('div');d.textContent=k.title+' — '+k.artist;if(i===idx)d.className='on';d.onclick=()=>{load(i,true);setMode('music')};l.appendChild(d)});
}
function load(i,play){
  if(!tracks.length)return;idx=(i+tracks.length)%tracks.length;
  audio.src=tracks[idx].url;
  renderList();paintPlayer();
  if(play){try{vid.pause()}catch(e){}audio.play().catch(()=>{})}
  if('mediaSession' in navigator)try{navigator.mediaSession.metadata=new MediaMetadata({title:tracks[idx].title,artist:tracks[idx].artist})}catch(e){}
}
document.querySelectorAll('.bPlay').forEach(b=>b.onclick=()=>{if(idx<0){$('file').click();return}audio.paused?audio.play():audio.pause()});
document.querySelectorAll('.bNext').forEach(b=>b.onclick=()=>load(idx+1,true));
document.querySelectorAll('.bPrev').forEach(b=>b.onclick=()=>{if(audio.currentTime>4)audio.currentTime=0;else load(idx-1,true)});
$('mSeek').onclick=e=>{const r=e.currentTarget.getBoundingClientRect();if(audio.duration)audio.currentTime=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*audio.duration};
$('mList').onclick=()=>setMode('media');
$('toMusic').onclick=()=>setMode('music');
audio.onplay=audio.onpause=paintPlayer;
audio.onended=()=>load(idx+1,true);
audio.ontimeupdate=audio.onloadedmetadata=paintPlayer;
if('mediaSession' in navigator){
  try{
    navigator.mediaSession.setActionHandler('nexttrack',()=>load(idx+1,true));
    navigator.mediaSession.setActionHandler('previoustrack',()=>load(idx-1,true));
  }catch(e){}
}

/* ================= الفيديو (شاشة كاملة) ================= */
const vid=$('vid');let vids=[],vi=-1,vHideT=null,vFit='contain';
function setImmersive(on){
  app.classList.toggle('immersive',on);
  $('vFsI').setAttribute('d',on?IC.fsx:IC.fs);
  setTimeout(()=>{try{map.invalidateSize({pan:false})}catch(e){}},100);
}
function showVCtl(){
  const L=$('videoL');L.classList.remove('hide');
  clearTimeout(vHideT);
  if(!vid.paused&&vids.length)vHideT=setTimeout(()=>L.classList.add('hide'),4500);
}
function paintVid(){
  $('vPi').setAttribute('d',vid.paused?'M8 5v14l11-7z':'M6 5h4v14H6zm8 0h4v14h-4z');
  $('vPb').style.width=(vid.duration?vid.currentTime/vid.duration*100:0)+'%';
  $('vCur').textContent=fmtT(vid.currentTime);$('vDur').textContent=fmtT(vid.duration);
  $('vFit').textContent=vFit==='contain'?t('fit'):t('fill');
}
$('vPick').onclick=$('vAdd').onclick=()=>$('vfile').click();
$('vfile').onchange=e=>{
  const first=vids.length;
  for(const f of e.target.files)vids.push({name:f.name.replace(/\.[^.]+$/,''),url:URL.createObjectURL(f)});
  e.target.value='';
  if(vids.length>first)loadVid(first,true);
};
function loadVid(i,play){
  if(!vids.length)return;
  vi=(i+vids.length)%vids.length;
  vid.src=vids[vi].url;$('vName').textContent=vids[vi].name;$('vEmpty').style.display='none';
  if(play){try{audio.pause()}catch(e){}vid.play().catch(()=>{})}
  paintVid();showVCtl();
}
$('vPlay').onclick=()=>{if(vi<0){$('vfile').click();return}vid.paused?vid.play():vid.pause();showVCtl()};
$('vNext').onclick=()=>loadVid(vi+1,true);
$('vPrev').onclick=()=>{if(vid.currentTime>4)vid.currentTime=0;else loadVid(vi-1,true)};
$('vBack10').onclick=()=>{vid.currentTime=Math.max(0,vid.currentTime-10);showVCtl()};
$('vFwd10').onclick=()=>{vid.currentTime=Math.min(vid.duration||1e9,vid.currentTime+10);showVCtl()};
$('vSeek').onclick=e=>{const r=e.currentTarget.getBoundingClientRect();if(vid.duration)vid.currentTime=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*vid.duration;showVCtl()};
$('vFit').onclick=()=>{vFit=vFit==='contain'?'cover':'contain';vid.style.objectFit=vFit;paintVid();showVCtl()};
$('vFs').onclick=()=>{setImmersive(!app.classList.contains('immersive'));showVCtl()};
$('vClose').onclick=()=>setMode('home');
$('videoL').addEventListener('click',e=>{
  if(e.target.closest('button,.seek'))return;
  const L=$('videoL');
  if(L.classList.contains('hide'))showVCtl();else if(!vid.paused){clearTimeout(vHideT);L.classList.add('hide')}
});
vid.onplay=vid.onpause=()=>{paintVid();showVCtl()};
vid.ontimeupdate=vid.onloadedmetadata=paintVid;
vid.onended=()=>{if(vids.length>1)loadVid(vi+1,true);else{paintVid();showVCtl()}};
vid.onerror=()=>{say(t('vidErr'))};

/* ================= الصور (السيارة + ويدجت الصورة) ================= */
let hasPhoto=false;
function setImg(varName,d){document.documentElement.style.setProperty(varName,d?'url('+d+')':(varName==='--photo'?'none':''))}
try{const s=localStorage.getItem('carimg');if(s)setImg('--carimg',s)}catch(e){}
try{const s=localStorage.getItem('photoimg');if(s){setImg('--photo',s);hasPhoto=true}}catch(e){}
let imgTarget=null;
function pickImage(target){imgTarget=target;$('imgFile').click()}
$('carPick').onclick=()=>pickImage('car');
$('photoPick').onclick=()=>pickImage('photo');
W.photo.onclick=()=>{if(app.dataset.mode==='home')pickImage('photo')};
$('carReset').onclick=()=>{setImg('--carimg','');try{localStorage.removeItem('carimg')}catch(e){}say(t('imgReset'))};
$('imgFile').onchange=e=>{
  const f=e.target.files[0];if(!f)return;
  const img=new Image(),u=URL.createObjectURL(f);
  img.onload=()=>{
    const k=Math.min(1,900/Math.max(img.width,img.height));
    const c=document.createElement('canvas');c.width=img.width*k;c.height=img.height*k;
    c.getContext('2d').drawImage(img,0,0,c.width,c.height);
    const d=c.toDataURL('image/jpeg',.82);
    if(imgTarget==='car'){setImg('--carimg',d);try{localStorage.setItem('carimg',d)}catch(x){}}
    else{setImg('--photo',d);hasPhoto=true;$('ph-t').textContent='';try{localStorage.setItem('photoimg',d)}catch(x){}}
    URL.revokeObjectURL(u);say(t('imgOk'));
  };
  img.src=u;e.target.value='';
};

/* ================= الاختصارات ================= */
[['📞','Phone','هاتف','','tel:'],['🗺️','Google Maps','خرائط قوقل','com.google.android.apps.maps','https://www.google.com/maps'],['🚙','Waze','واز','com.waze','https://waze.com/ul'],['▶️','YouTube','يوتيوب','com.google.android.youtube','https://m.youtube.com'],['🎧','Spotify','سبوتيفاي','com.spotify.music','https://open.spotify.com'],['💬','WhatsApp','واتساب','com.whatsapp','https://wa.me/']].forEach(a=>{
  const b=document.createElement('button');b.innerHTML=`<span>${a[0]}</span>${a[1]}`;b.dataset.ar=a[2];b.dataset.en=a[1];
  b.onclick=()=>a[3]?openApp(a[3],a[4]):openExt(a[4]);$('w-apps').appendChild(b);
});
{const b=document.createElement('button');b.innerHTML='<span>⋯</span><i data-i="allApps"></i>';b.onclick=openAllApps;$('w-apps').appendChild(b)}

/* ================= الإعدادات ================= */
$('fs').onclick=()=>{try{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}catch(e){}};
$('wake').onclick=async()=>{try{await navigator.wakeLock.request('screen');say(t('wakeOk'))}catch(e){say(t('notSup'))}};
function paintSettings(){
  const on=v=>v?t('on'):t('off');
  $('sClock').textContent=t('clockFmt')+': '+(cfg.h24?t('h24'):t('h12'));
  $('sTopSpd').textContent=t('topSpd')+': '+on(cfg.topSpd);
  $('sTopClock').textContent=t('topClock')+': '+on(cfg.topClock);
  $('sTopTemp').textContent=t('topTemp')+': '+on(cfg.topTemp);
  $('lim').textContent=t('limMode')+': '+(cfg.autoLimit?t('limAuto'):t('limManual'));
}
$('sClock').onclick=()=>{cfg.h24=!cfg.h24;save();paintSettings();tick()};
$('sTopSpd').onclick=()=>{cfg.topSpd=!cfg.topSpd;save();paintSettings();paintTop()};
$('sTopClock').onclick=()=>{cfg.topClock=!cfg.topClock;save();paintSettings();paintTop()};
$('sTopTemp').onclick=()=>{cfg.topTemp=!cfg.topTemp;save();paintSettings();paintTop()};
$('lim').onclick=()=>{
  cfg.autoLimit=!cfg.autoLimit;save();
  if(cfg.autoLimit){limPos=null;limT=0;if(lastLL)fetchLimit(lastLL,curSpeed)}
  paintSettings();paintLimit();
};

/* ================= المؤشرات ================= */
const GC={coolant:{n:['Coolant temp','حرارة المكينة'],u:'°C',min:40,max:130,hi:105},fuel:{n:['Fuel','البنزين'],u:'%',min:0,max:100,lo:15},rpm:{n:['RPM','الدوران'],u:'rpm',min:0,max:8000,hi:6500},oil:{n:['Oil temp','حرارة الزيت'],u:'°C',min:40,max:150,hi:130},volt:{n:['Battery','البطارية'],u:'V',min:10,max:16,lo:11.8,hi:15.2},load:{n:['Engine load','حمل المحرك'],u:'%',min:0,max:100}};
const ARC=2*Math.PI*48,SPAN=ARC*240/360,gv={};
function mkGauge(k){
  const g=document.createElement('div');g.className='gauge';g.dataset.g=k;
  g.innerHTML=`<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="48" fill="none" stroke="rgba(255,255,255,.1)" stroke-width="9" stroke-linecap="round" stroke-dasharray="${SPAN} ${ARC}" transform="rotate(150 60 60)"/><circle class="gar" cx="60" cy="60" r="48" fill="none" stroke="#1e8cff" stroke-width="9" stroke-linecap="round" stroke-dasharray="0 ${ARC}" transform="rotate(150 60 60)"/></svg><div class="gv">--</div><div class="gl"></div>`;
  return g;
}
function paintG(g){
  const k=g.dataset.g,c=GC[k],v=gv[k],el=g.querySelector('.gv'),ar=g.querySelector('.gar');
  g.querySelector('.gl').textContent=c.n[LANG];
  if(v==null){el.textContent='--';el.style.color='';ar.setAttribute('stroke-dasharray','0 '+ARC);return}
  const f=Math.max(0,Math.min(1,(v-c.min)/(c.max-c.min)));
  const bad=(c.hi!=null&&v>=c.hi)||(c.lo!=null&&v<=c.lo);
  ar.setAttribute('stroke-dasharray',Math.max(.01,SPAN*f)+' '+ARC);ar.setAttribute('stroke',bad?'#ff4d4f':'#1e8cff');
  el.innerHTML=(k==='volt'?v.toFixed(1):Math.round(v))+'<small>'+c.u+'</small>';el.style.color=bad?'#ff6b6d':'';el.style.fontSize=k==='rpm'?'clamp(20px,4.6vh,40px)':'';
}
function paintAll(){document.querySelectorAll('.gauge').forEach(paintG)}
function setG(k,v){gv[k]=v;document.querySelectorAll('.gauge[data-g="'+k+'"]').forEach(paintG)}
['coolant','fuel','rpm','oil','volt','load'].forEach(k=>$('ggrid').appendChild(mkGauge(k)));
['coolant','fuel'].forEach(k=>$('w-gauges').appendChild(mkGauge(k)));

/* ================= OBD WiFi ================= */
let obdOn=false,demoT=null,obdSpeedAt=0;
try{$('obdHost').value=localStorage.getItem('obdHost')||$('obdHost').value;$('obdPort').value=localStorage.getItem('obdPort')||$('obdPort').value}catch(e){}
function setObdBtn(){$('obdBtn').textContent=obdOn?t('obdDisc'):t('obdConn');$('demoBtn').textContent=demoT?t('demoStop'):t('demo')}
window.onObd=d=>{
  ['coolant','fuel','rpm','oil','volt','load'].forEach(k=>{if(d[k]!=null)setG(k,d[k])});
  if(d.ambient!=null){tempObd=d.ambient;tempObdAt=Date.now();paintTemp()}
  if(d.speed!=null){obdSpeedAt=Date.now();setSpeed(Math.round(d.speed))}
};
window.onObdStatus=s=>{
  obdOn=(s==='connecting'||s==='connected');
  $('obdSt').textContent=s==='connecting'?t('stConnecting'):s==='connected'?t('stConnected'):s==='closed'?t('stClosed'):t('stError')+': '+s.replace(/^error:/,'');
  setObdBtn();
};
$('obdBtn').onclick=()=>{
  if(obdOn){try{Android.obdDisconnect()}catch(e){}window.onObdStatus('closed');return}
  if(!(window.Android&&Android.obdConnect)){$('obdSt').textContent=t('needApk');return}
  stopDemo();
  const h=$('obdHost').value.trim(),p=parseInt($('obdPort').value)||35000;
  try{localStorage.setItem('obdHost',h);localStorage.setItem('obdPort',p)}catch(e){}
  Android.obdConnect(h,p);window.onObdStatus('connecting');
};
function stopDemo(){clearInterval(demoT);demoT=null;setObdBtn()}
$('demoBtn').onclick=()=>{
  if(demoT){stopDemo();return}
  let f=64,tmp=70;
  demoT=setInterval(()=>{
    tmp=Math.min(92,tmp+.6+Math.random()*.4);f=Math.max(5,f-.02);
    window.onObd({coolant:tmp,fuel:f,rpm:800+Math.random()*1600,oil:tmp+8,volt:13.8+Math.random()*.4,load:15+Math.random()*30});
  },900);setObdBtn();
};

/* ================= حجم الأيقونات والشاشة ================= */
function applyScale(){
  document.documentElement.style.setProperty('--is',cfg.is);
  app.style.transform=cfg.ss<1?'scale('+cfg.ss+')':'';
  $('isR').value=Math.round(cfg.is*100);$('ssR').value=Math.round(cfg.ss*100);
  $('isV').textContent=Math.round(cfg.is*100)+'%';$('ssV').textContent=Math.round(cfg.ss*100)+'%';
  setTimeout(()=>{try{map.invalidateSize({pan:false})}catch(e){}},120);
}
$('isR').oninput=e=>{cfg.is=e.target.value/100;save();applyScale()};
$('ssR').oninput=e=>{cfg.ss=e.target.value/100;save();applyScale()};
$('sizeReset').onclick=()=>{cfg.is=1;cfg.ss=1;save();applyScale()};

/* ================= تطبيق اللغة ================= */
function applyLang(){
  document.querySelectorAll('[data-i]').forEach(e=>e.textContent=t(e.dataset.i));
  $('q').placeholder=t('search');
  $('nomap').textContent=t('nomap');
  if(!steps.length)setTurn('straight','--',t('noRoute'));
  $('ph-t').textContent=hasPhoto?'':t('pickPhoto');
  renderList();buildEditBar();refreshCovers();paintAll();setObdBtn();
  paintPlayer();paintVid();paintSettings();paintLimit();paintTemp();
  document.documentElement.lang=LANG?'ar':'en';
}

/* ================= تشغيل ================= */
safe(()=>{$('logoImg').src='logo.png'});
safe(place);
safe(applyLang);
safe(applyScale);
safe(()=>setTilt(true));
safe(paintTop);
safe(()=>{vol=readVol();paintVol()});
safe(tick);setInterval(()=>safe(tick),5000);
safe(()=>{$('volR').value=vol});
safe(()=>setImmersive(false));
safe(startGPS);
loadLeaflet(0);
document.body.addEventListener('contextmenu',e=>e.preventDefault());
